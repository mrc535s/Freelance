=== Plugin Name ===
Contributors: Genkisan
Tags: announcement, admin
Requires at least: 2.0.0
Tested up to: 2.7.0
Stable tag: 1.4.0

Display an announcement on your blog

== Description ==

- easily switch on and off through Admin Options
- display message without editing theme files (above 1st post or through widget)
- display different message to different roles/users
- timer to switch on & off announcement (only in WP 2.1 and above)

**Demo:**
[Plugin Details & Demo](http://ericulous.com/2007/03/09/genki_announcement/)

== Installation ==

1. Upload genki_announcement folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure options in Admin Panel > Options > Genki Announcement.

== Screenshots ==

1. Admin Panel