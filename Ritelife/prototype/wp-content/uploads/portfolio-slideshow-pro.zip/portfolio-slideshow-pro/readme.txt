=== Portfolio Slideshow Pro ===
Author: Raygun
Author URL: http://madebyraygun.com
Plugin URL: http://madebyraygun.com/lab/portfolio-slideshow
Tags: slideshow, gallery, images, photos, photographs, portfolio, jquery, cycle, indexexhibit
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 1.4.1

All documentation and release notes for this plugin are maintained at http://madebyraygun.com/lab/portfolio-slideshow/documentation.