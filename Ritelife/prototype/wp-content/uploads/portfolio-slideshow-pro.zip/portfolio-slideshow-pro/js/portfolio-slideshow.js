/**
 * jQuery Plugin to obtain touch gestures from iPhone, iPod Touch and iPad, should also work with Android mobile phones (not tested yet!)
 * Common usage: wipe images (left and right to show the previous or next image)
 * 
 * @author Andreas Waltl, netCU Internetagentur (http://www.netcu.de)
 * @version 1.1.1 (9th December 2010) - fix bug (older IE's had problems)
 * @version 1.1 (1st September 2010) - support wipe up and wipe down
 * @version 1.0 (15th July 2010)
 */
(function($){$.fn.touchwipe=function(settings){var config={min_move_x:20,min_move_y:20,wipeLeft:function(){},wipeRight:function(){},wipeUp:function(){},wipeDown:function(){},preventDefaultEvents:true};if(settings)$.extend(config,settings);this.each(function(){var startX;var startY;var isMoving=false;function cancelTouch(){this.removeEventListener('touchmove',onTouchMove);startX=null;isMoving=false}function onTouchMove(e){if(config.preventDefaultEvents){e.preventDefault()}if(isMoving){var x=e.touches[0].pageX;var y=e.touches[0].pageY;var dx=startX-x;var dy=startY-y;if(Math.abs(dx)>=config.min_move_x){cancelTouch();if(dx>0){config.wipeLeft()}else{config.wipeRight()}}else if(Math.abs(dy)>=config.min_move_y){cancelTouch();if(dy>0){config.wipeDown()}else{config.wipeUp()}}}}function onTouchStart(e){if(e.touches.length==1){startX=e.touches[0].pageX;startY=e.touches[0].pageY;isMoving=true;this.addEventListener('touchmove',onTouchMove,false)}}if('ontouchstart'in document.documentElement){this.addEventListener('touchstart',onTouchStart,false)}});return this}})(jQuery);


jQuery(document).ready(function ($) {

	var psLoader, psHash, psFancyBox, psInfoTxt, hoverCaps, psFluid, psTouchSwipe, psKeyboarNav;
	currSlide = new Array(); tabSlide = new Array();
	psLoader = portfolioSlideshowOptions.psLoader;
	psFluid = portfolioSlideshowOptions.psFluid;
	psHash = portfolioSlideshowOptions.psHash;
	psFancyBox = portfolioSlideshowOptions.psFancyBox;
	psTouchSwipe = portfolioSlideshowOptions.psTouchSwipe;
	psKeyboardNav = portfolioSlideshowOptions.psKeyboardNav;
	psInfoTxt = portfolioSlideshowOptions.psInfoTxt;

	if ( jQuery.browser.msie && parseInt( jQuery.browser.version ) < 8 ) { //sets ie var to true if IE is 7 or below. Necessary for some style & functionality issues.
		ie = true; 
	} else { 
		ie = false 
	}
		
	//load our Fancybox scripts
	if (psFancyBox === true) {
		function formatTitle (title, currentArray, currentIndex, currentOpts) {
			return '<div id="image-caption">' + (title && title.length ? '<b>' + title + '</b>' : '' ) + ' Image ' + (currentIndex + 1) + ' of ' + currentArray.length + '</div>';
			}
		
			$("a.fancybox, .gallery-item 'a[href$='.gif'], .gallery-item 'a[href$='.jpg'], .gallery-item 'a[href$='.png'], .gallery-item 'a[href$='.jpeg']").fancybox({
			'titlePosition' : 'inside',
			'titleFormat' : formatTitle
		});

	}
	
	if (psLoader === true) { //if we're supposed to show a loader
		$('.slideshow-wrapper').delay(1000).queue(function() {
			$('.portfolio-slideshow, .slideshow-nav, .pager').css('visibility', 'visible');
			$(this).removeClass("showloader");
		});	
	}
		
	$("div[id^=portfolio-slideshow]").each(function () {
	
		var num = this.id.match(/portfolio-slideshow(\d+)/)[1];
			
			if ( ie === true ) {
				$('#slideshow-wrapper' + num).addClass('ie');
			}

			//load our scrollable carousel
			$('#scrollable' + num).scrollable({keyboard:false}).navigator({navi: "#carouselnav" + num, naviItem: 'a'});
	
			/* Toggle actions */

			$('#slideshow-wrapper' + num + ' a.show').click(function() {
				$(this).hide();
				$('#slideshow-wrapper' + num + ' a.hide').addClass('active');
				$('#slideshow-wrapper' + num + ' .pscarousel').fadeIn('fast');
			});		
			
			$('#slideshow-wrapper' + num + ' a.hide').click(function() {
				$(this).removeClass('active');
				$('#slideshow-wrapper' + num + ' a.show').show();
				$('#slideshow-wrapper' + num + ' .pscarousel').fadeOut('fast');
			});		
			
			/* End toggles */
			
			$(function () {
				var index = 0, hash = window.location.hash;
				if (/\d+/.exec(hash)) {
				index = /\d+/.exec(hash)[0];
				index = (parseInt(index) || 1) - 1; // slides are zero-based
			}

			// Set up active pager links for the two slideshow configurations
			if (psPagerStyle[num] === 'thumbs') {
				$.fn.cycle.updateActivePagerLink = function(pager, currSlideIndex) { 
				$(pager).find('img').removeClass('activeSlide') 
				.filter('#pager' + num + ' img:eq('+currSlideIndex+')').addClass('activeSlide'); 
				};
			} else {
				$.fn.cycle.updateActivePagerLink = function(pager, currSlideIndex) { 
				$(pager).find('a').removeClass('activeSlide') 
				.filter('#pager' + num + ' a:eq('+currSlideIndex+')').addClass('activeSlide'); 
				};
			}	


			//two different Cycle configs, depending on the pager option
			function cyclePager() {
				$('#portfolio-slideshow' + num).cycle({
					fx: psTrans[num],
					speed: psSpeed[num],
					timeout: psTimeout[num],
					random: psRandom[num],
					nowrap: psNoWrap[num],
					next: '#slideshow-wrapper' + num + ' a.slideshow-next, #slideshow-wrapper' + num + ' #psnext' + num,
					startingSlide: index,
					prev: '#slideshow-wrapper' + num + ' a.slideshow-prev , #slideshow-wrapper' + num + ' #psprev' + num,
					before:	onBefore,
					after:	onAfter,
					end:	onEnd,
					slideExpr:	'.slideshow-content',
					manualTrump: true,
					slideResize: false,
					containerResize: false,
					pager:  '#pager' + num,
					cleartypeNoBg: true,
					pagerAnchorBuilder: buildAnchors
				});
			}	
			
			function cycleNumbersPager() {
				$('#portfolio-slideshow' + num).cycle({
					fx: psTrans[num],
					speed: psSpeed[num],
					timeout: psTimeout[num],
					random: psRandom[num],
					nowrap: psNoWrap[num],
					next: '#slideshow-wrapper' + num + ' a.slideshow-next, #psnext' + num,
					startingSlide: index,
					prev: '#slideshow-wrapper' + num + ' a.slideshow-prev, #psprev' + num,
					before:     onBefore,
					after:	onAfter,
					slideExpr:	'.slideshow-content',
					end:	onEnd,
					manualTrump: true,
					slideResize: false,
					containerResize: false,
					pager:  '#pager' + num + ' .numbers', 
					cleartypeNoBg: true
				});
			}
		
			
			$(window).load(function() { //Wait until the images are loaded to begin the cycle
				if (psPagerStyle[num] === "numbers") {
					cycleNumbersPager();
					ps_initialize();			
				} else {
					cyclePager();
					ps_initialize();							
				}
			});	
	
			
			function ps_initialize() {	
				//pause the slideshow right away if autoplay is off
				if ( psAutoplay[num] === false ) {
					$('#portfolio-slideshow' + num).cycle('pause');
				} else {
			
					if ( psAudio[num] === true ) {
						$('#portfolio-slideshow' + num).delay(1000).queue(function() {
							$('#portfolio-slideshow' + num).cycle('resume');	
							$('#slideshow-nav' + num + ' a.play').fadeOut(100, function(){
							$('#slideshow-nav' + num + ' a.pause').fadeIn(10);});	
							$('#portfolio-slideshow' + num).parent().nextAll('.haiku-text-player:first').jPlayer('play');
						});
					} else {
						$('#slideshow-nav' + num + ' a.play').fadeOut(100, function(){
						$('#slideshow-nav' + num + ' a.pause').fadeIn(10);});	
					}	
				}
			}
			
			//pause
			$('#slideshow-nav' + num + ' a.pause').click(function() { 
				$(this).fadeOut(100, function(){
					$('#slideshow-nav' + num + ' a.play').fadeIn(10);});
				if (psAudio[num] === true) {
					$(this).parent().parent().nextAll('.haiku-text-player:first').jPlayer('pause');
				}
				$('#portfolio-slideshow' + num).cycle('pause');
			});
		
			//play
			$('#slideshow-nav' + num + ' a.play').click(function() { 
				$('#portfolio-slideshow' + num).cycle('resume');
				$(this).fadeOut(100, function(){
					$('#slideshow-nav' + num + ' a.pause').fadeIn(10);});
				if ( psAudio[num] === true ) {
					$(this).parent().parent().nextAll('.haiku-text-player:first').jPlayer('play');
				}	
			});

			//restart
			$('#slideshow-nav' + num + ' a.restart').click(function() { 
				$('#pager' + num + ' .numbers').empty();
				$(this).fadeOut(100, function(){
					$('#slideshow-nav' + num + ' a.pause').fadeIn(10);});
				if ( psAudio[num] === true ) {
					$(this).parent().parent().nextAll('.haiku-text-player:first').jPlayer('play');	
				}

				if (psPagerStyle[num] === "numbers") {
					cycleNumbersPager();			
				} else {
					cyclePager();							
				}
			
			});	

			if ( psFluid === true ) {				
				$(window).resize(function() { //on window resize, force resize of the slideshows
					$('#portfolio-slideshow' + num).css('width','').css('height','');	
					var $h, $w;
					$h = $('#portfolio-slideshow' + num).find('.slideshow-content').eq(currSlide[num]).outerHeight();
					$w = $('#portfolio-slideshow' + num).find('.slideshow-content').eq(currSlide[num]).width();
					$('#portfolio-slideshow' + num).css("height", $h).css("width", $w);
				});
		
			}	
			
				$('#slideshow-wrapper' + num + '.hover .slideshow-content').hover(
				  function () {
					$('#portfolio-slideshow' + num + ' .slideshow-meta').fadeTo('fast', 1);
				  }, 
				  function () {
				   $('#portfolio-slideshow' + num + ' .slideshow-meta').fadeTo('fast', 0);
				 });

			if ( psKeyboardNav === true ) {
				$(document).keydown(function(e){
					if(e.which == 37){
						$('#psprev' + num).click();
					} else if(e.which == 39) {
						$('#psnext' + num).click();
					}
				});
			}	
	
			if ( psTouchSwipe === true ) {
				$('#portfolio-slideshow' + num + ' .slideshow-content img').touchwipe({
					 wipeLeft: function() { $('#psnext' + num).click() },
					 wipeRight: function() { $('#psprev' + num).click() }
				});
			}	
			
			//build anchors
			function buildAnchors(idx, slide) { 
				if (psPagerStyle[num] === 'thumbs') {
					return '#pager' +num+ ' img:eq(' + (idx) + ')'; 
				}
				if (psPagerStyle[num] === "bullets") {
					 return '#pager' +num+ ' a:eq(' + (idx) + ')'; 
				}	 
			}
			
			function onBefore(curr,next,opts) {
				tabSlide[num] = opts.nextSlide + 1;
				//This drives the tabs
				var psTabs = Math.ceil( ( ( tabSlide[num] ) / psCarouselSize[num] ) -1 );
				$('#carouselnav' + num + ' a').eq(psTabs).click();
			
				//this adjusts the height & width of the slideshow
				var $h,$w;
				$h = $(this).height(); //slideshow content height
				$w = $(next).width(); //slideshow content height
				$('#portfolio-slideshow' + num).height($h).width($w);
			}
				
			
			function onAfter(curr,next,opts) {
				currSlide[num] = opts.currSlide;		
				var $h,$w;
				$h = $(this).height(); //slideshow content height
				$w = $(next).width(); //slideshow content height
													
				if ( ie === true ) {
					$('#portfolio-slideshow' + num).height($h).width($w);
				}

								
				if ( psNoWrap[num] === true ) { //if wrapping is disabled, fade out the controls at the appropriate time
					if (opts.currSlide === 0 ) {
						$('#slideshow-nav' + num + ' .slideshow-prev, #slideshow-nav' + num + ' .sep').addClass('inactive');
					} else {
						$('#slideshow-nav' + num + ' .slideshow-prev, #slideshow-nav' + num + ' .sep').removeClass('inactive');
					}
						
					if (opts.currSlide === opts.slideCount-1) {
						$('#slideshow-nav' + num + ' .slideshow-next, #slideshow-nav' + num + ' .sep').addClass('inactive');
					} else {
						$('#slideshow-nav' + num + ' .slideshow-next').removeClass('inactive');
					}
				}

				if (psHash === true) { 
					window.location.hash = opts.currSlide + 1;
				}

				var caption = (opts.currSlide + 1) + ' ' + psInfoTxt + ' ' + opts.slideCount;
				$('.slideshow-info' + num).html(caption);
			} 

			function onEnd() {
				$('#slideshow-nav' + num + ' .slideshow-next, #slideshow-nav' + num + ' .sep').addClass('inactive');
				$('#slideshow-nav' + num + ' a.pause').hide();
				$('#slideshow-nav' + num + ' a.play').hide();
				$('#slideshow-nav' + num + ' a.restart').show();	
			}
			
		});
	});
});
